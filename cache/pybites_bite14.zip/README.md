## [Bite 14. Generate a table of n sequences](https://codechalleng.es/bites/14/)

Good luck and please share you code in the Bite forums upon completion.

For questions [join our Community](https://pybites.circle.so) (no spoilers please).

Check out our full catalogue of Bites of Py [here](https://codechalleng.es/bites/catalogue).

Enjoy and keep calm and code in Python!